package pe.idat.ec2_ruiz_jean

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.BasicText
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import pe.idat.ec2_ruiz_jean.ui.theme.Ec2RuizJeanTheme


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MyApp()
        }
    }
}

@Composable
fun MyApp() {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = "menu") {
        composable("menu") { MenuScreen(navController) }
        composable("questionnaire") { QuestionnaireScreen(navController) }
    }
}

@Composable
fun MenuScreen(navController: NavHostController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(text = "Consultorio", fontSize = 24.sp, modifier = Modifier.padding(bottom = 16.dp))

        Button(
            onClick = { navController.navigate("questionnaire") },
            modifier = Modifier.padding(bottom = 8.dp)
        ) {
            Text(text = "Cuestionario")
        }

        Button(
            onClick = { /* Acción para el botón Resultado */ }
        ) {
            Text(text = "Resultado")
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuestionnaireScreen(navController: NavHostController) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Cuestionario") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp)
        ) {
            Question1()
            Question2()
            Question3()
            Question4()
            Question5()
            Spacer(modifier = Modifier.height(16.dp))
            Button(
                onClick = { /* Acción para el botón Resolver */ },
                modifier = Modifier.align(Alignment.CenterHorizontally)
            ) {
                Text(text = "Resolver")
            }
        }
    }
}

@Composable
fun Question1() {
    Text("1. Marque sus platos favoritos:", fontWeight = FontWeight.Bold)
    val dishes = listOf("Arroz con pollo", "Lomo saltado", "Ají de gallina", "Tallarines", "Arroz chaufa", "Otro")
    dishes.forEach { dish ->
        var checked by remember { mutableStateOf(false) }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = checked, onCheckedChange = { checked = it })
            Text(dish)
        }
    }
}

@Composable
fun Question2() {
    Spacer(modifier = Modifier.height(16.dp))
    Text("2. Visitaste algún país de Europa, Asia o África?", fontWeight = FontWeight.Bold)
    val options = listOf("Sí", "No")
    options.forEach { option ->
        var checked by remember { mutableStateOf(false) }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = checked, onCheckedChange = { checked = it })
            Text(option)
        }
    }
}

@Composable
fun Question3() {
    Spacer(modifier = Modifier.height(16.dp))
    Text("3. ¿Hablas Inglés?", fontWeight = FontWeight.Bold)
    val options = listOf("Sí", "No")
    options.forEach { option ->
        var checked by remember { mutableStateOf(false) }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = checked, onCheckedChange = { checked = it })
            Text(option)
        }
    }
}

@Composable
fun Question4() {
    Spacer(modifier = Modifier.height(16.dp))
    Text("4. ¿Te gusta la tecnología?", fontWeight = FontWeight.Bold)
    val options = listOf("Sí", "No")
    options.forEach { option ->
        var checked by remember { mutableStateOf(false) }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = checked, onCheckedChange = { checked = it })
            Text(option)
        }
    }
}

@Composable
fun Question5() {
    Spacer(modifier = Modifier.height(16.dp))
    Text("5. ¿Realizas trabajo remoto?", fontWeight = FontWeight.Bold)
    val options = listOf("Sí", "No")
    options.forEach { option ->
        var checked by remember { mutableStateOf(false) }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = checked, onCheckedChange = { checked = it })
            Text(option)
        }
    }
}

@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    MyApp()
}